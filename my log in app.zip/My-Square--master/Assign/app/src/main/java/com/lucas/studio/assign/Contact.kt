package com.lucas.studio.assign

class Contact{
    var name:String = ""
    var phone:String = ""
    var phone2:String = ""
    var description:String =""

    constructor(name: String, phone:String, phone2:String, description:String){
        this.name = name
        this.phone = phone
        this.phone2 = phone2
        this.description = description
    }
    constructor()
}